var fs = require('fs')
var Student = require('./student')

var express = require('express')
var router = express.Router()
router.get('/',function(req,res){
    //fs.readFile('./db.json','utf8',function(err,data){
    
    //})
    Student.find(function(err,students){
        if(err){
            return res.status(500).send('Server error')
         }
        //var students = JSON.parse(data).students
         res.render('index.html',{
             name:[
                 '张三',
                 '王明',
                 '李华'
             ],
             students: students
             })
    })
}) 
router.get('/students/new',function(req,res){
    res.render('new.html')
})
router.post('/students/new',function(req,res){
    Student.save(req.body,function(err){
        if(err){
            return res.status(500).send('Server error')
        }
        res.redirect('/')
    })
})
router.get('/students/edit',function(req,res){
    Student.findById(parseInt(req.query.id),function(err,student){
        if(err){
            return res.status(500).send('Server error')
        }
        res.render('edit.html',{
            student:student
        })
    })
})
router.post('/students/edit',function(req,res){
    Student.updateById(req.body,function(err){
        if(err){
            return res.status(500).send('Server error')
        }
        res.redirect('/')
    })
})

router.get('/students/delete',function(req,res){
    Student.deleteById(req.query.id,function(err){
        if(err){
            return res.status(500).send('Server error')
        }
        res.redirect('/')
    })
})

router.get('/login',function(req,res){
    res.render('login.html')
})

router.post('/login',function(req,res){

})

router.get('/register',function(req,res){
    res.render('register.html')
})

router.post('/register',function(req,res){

})

module.exports = router

